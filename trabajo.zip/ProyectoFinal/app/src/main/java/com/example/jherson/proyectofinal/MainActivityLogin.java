package com.example.jherson.proyectofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivityLogin extends AppCompatActivity {

    private EditText txtusuario;
    private EditText txtpassword;
    private Button btnIngresar;
    private String user = "admin";
    private int pass = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);
        txtusuario=(EditText)findViewById(R.id.txtusuario);
        txtpassword=(EditText)findViewById(R.id.txtpassword);
        btnIngresar=(Button)findViewById(R.id.btnIngresar);

    }

    public void iniciar(View view){
        Verificar();
    }

    private void Verificar() {
        String ini = txtusuario.getText().toString();
        int pas = Integer.parseInt(txtpassword.getText().toString());
        if (ini.equals(user)&&pas==pass){
            Intent intent = new Intent(getApplicationContext(),MainActivityPrincipal.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this,"Error!", Toast.LENGTH_SHORT).show();
        }
    }

}
