package com.example.jherson.proyectofinal;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.airbnb.lottie.LottieAnimationView;

public class MainActivityMensaje extends AppCompatActivity {

    EditText txtNumero, txtMensaje;
    Button btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_mensaje);

        final LottieAnimationView lottieAnimationView = (LottieAnimationView)findViewById(R.id.AnimationView);

        lottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lottieAnimationView.loop(false);
                lottieAnimationView.playAnimation();
            }
        });

        txtNumero = (EditText)findViewById(R.id.txtNumero);
        txtMensaje = (EditText)findViewById(R.id.txtMensaje);
        btnEnviar = (Button) findViewById(R.id.btnEnviar);

        if (ContextCompat.checkSelfPermission(MainActivityMensaje.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivityMensaje.this,Manifest.permission.SEND_SMS)){
                ActivityCompat.requestPermissions(MainActivityMensaje.this,new String[]{Manifest.permission.SEND_SMS},1);
            }else{
                ActivityCompat.requestPermissions(MainActivityMensaje.this, new String[]{Manifest.permission.SEND_SMS},1);
            }
        }else {

        }

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numero = txtNumero.getText().toString();
                String sms = txtMensaje.getText().toString();

                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(numero,null,sms,null,null);
                    Toast.makeText(MainActivityMensaje.this,"Enviado",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(MainActivityMensaje.this,"Error",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requesCode, String [] permissions, int [] grantResults){
        switch (requesCode){
            case 1: {
                if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if (ContextCompat.checkSelfPermission(MainActivityMensaje.this,Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(MainActivityMensaje.this,"Permiso Otorgado",Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(MainActivityMensaje.this,"Permiso Denegado",Toast.LENGTH_SHORT).show();
                    }
                }return;
            }
        }
    }

}
