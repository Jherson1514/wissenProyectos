package com.example.jherson.proyectofinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivityPrincipal extends AppCompatActivity {

    ImageButton btngps, btnllamar,btnmensaje, btninternet, btncamara;
    Button btnregresar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_principal);
        btngps = (ImageButton)findViewById(R.id.btngps);
        btnllamar = (ImageButton)findViewById(R.id.btnllamar);
        btnmensaje = (ImageButton)findViewById(R.id.btnmensaje);
        btninternet = (ImageButton)findViewById(R.id.btninternet);
        btncamara = (ImageButton)findViewById(R.id.btncamara);
        btnregresar = (Button)findViewById(R.id.btnregresar);
    }

    public void gps(View view){
        llamargps();
    }

    private void llamargps() {
        Intent intent = new Intent(getApplicationContext(),MapsActivityGps.class);
        startActivity(intent);
    }

    public void llamar(View view){
        llamarllamada();
    }

    private void llamarllamada() {
        Intent intent = new Intent(getApplicationContext(),MainActivityLlamada.class);
        startActivity(intent);
    }

    public void mensaje(View view){
        llamarmensaje();
    }

    private void llamarmensaje() {
        Intent intent = new Intent(getApplicationContext(),MainActivityMensaje.class);
        startActivity(intent);
    }

    public void internet(View view){
        llamarinternet();
    }

    private void llamarinternet() {
        Intent intent = new Intent(getApplicationContext(),MainActivityNavegador.class);
        startActivity(intent);
    }

    public void camara(View view){
        llamarcamara();
    }

    private void llamarcamara() {
        Intent intent = new Intent(getApplicationContext(),MainActivityCamara.class);
        startActivity(intent);
    }

    public void principal(View view){
        llamarprincipal();
    }

    private void llamarprincipal() {
        Intent intent = new Intent(getApplicationContext(),MainActivityLogin.class);
        startActivity(intent);
    }

}
